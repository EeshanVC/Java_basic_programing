// 4.Try with catch and fanilly block

package ExceptionHandling;

import java.util.Scanner;

public class code5 {
    public static void main(String[] args) {
        try {
                Scanner sc = new Scanner(System.in);
                System.out.println("Enter the first number : ");
                int num1 = sc.nextInt();//Critical Statement -- > InputMistmatchException
                System.out.println("Enter the second number : ");
                int num2 = sc.nextInt();//Critical Statement -- > InputMistmatchException
                int res = num1/num2;//Critical Statement -- > ArithmeticException
                System.out.println("Result is = "+res);
        }       
            // generic catch block
            catch(Exception e){
                System.out.println("Exception handled");
            }
            finally{
                System.out.println("Hi from finally");
            }
                //Irrespective of what the exception is the finally block certainly get excuted 
                //i.e even if the xception gets generated the program will first print finally content and then displaythe exceptoion message provide it is from DEH
    }
}

