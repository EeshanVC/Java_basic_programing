package ExceptionHandling;
import java.util.*;
//2. Using try with multiple catch block
//all the specific catch blocks must be above the generic catch so that the catch block does not turn to be un-rechable
public class code3 {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the first number : ");
            int num1 = sc.nextInt();//Critical Statement -- > InputMistmatchException
            System.out.println("Enter the second number : ");
            int num2 = sc.nextInt();//Critical Statement -- > InputMistmatchException
            int res = num1/num2;//Critical Statement -- > ArithmeticException
            System.out.println("Result is = "+res);
            System.out.println("--------------");
            System.out.println("Enter the array size : ");
            int n = sc.nextInt();//Critical Statement -- > InputMistmatchException
            int arr[] = new int[n];//Critical Statement -- > NegativeArraySizeException
            System.out.println("Enter the position into which the value has to be added : ");
            int pos = sc.nextInt();//Critical Statement -- > InputMistmatchException
            System.out.println("Enter the value which that has to be added : ");
            int val = sc.nextInt();//Critical Statement -- > InputMistmatchException
            arr[pos] = val;//Critical Statement -- > ArrayIndexOutOfBoundsException
            System.out.println("value is added");
        }
        //specific catch
        catch (InputMismatchException e1) {
            System.out.println("Inputs are not matching");
        }
        catch (ArithmeticException e2){
            System.out.println("Arithmetic Exception is generated due to / by zero issue");
        }
        catch(NegativeArraySizeException e3){
            System.out.println("Array sizze cannot be negative");

        }
        catch(ArrayIndexOutOfBoundsException e4){
            System.out.println("Please specify the index within the range");
        }
        // generic catch block
        catch(Exception e){
            System.out.println("Exception handled");
        }
    }
}    



