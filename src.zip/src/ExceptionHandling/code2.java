package ExceptionHandling;

import java.util.Scanner;

/*
 * * Exceptions in java can be handled in 3 ways:
* 1. Using try and catch blocks
* 2. Using throws keyword
* 3. Using throw keyword


* Using try and catch blocks
* 1. Using try with single catch block
* 2. try with multiple catch
* 3. try with multi-catch
* 4. try with catch and finally
* 5. try with resource
* 6. try with finally
*/
//1. Using try with single catch block
// all critical statements must be kept inside the try block and solution to exception must be in catch block
public class code2 {
    public static void main(String[] args) {
        try{
             Scanner sc = new Scanner(System.in);
        System.out.println("enter the 1st number: ");
        int num1 = sc.nextInt(); // Critical statment --> InputMismatchException
        System.out.println("enter the 2nd number: ");
        int num2 = sc.nextInt(); // Critical statment --> InputMismatchException
        int res = num1/num2; // Critical statment --> ArithmethicException
        System.out.println("result : "+res);

        System.out.println("======================");
        System.out.println("enter the array size: ");
        int n= sc.nextInt(); // Critical statment --> InputMismatchException
        int arr[] = new int[n]; // Critical statment --> NegativeArraySizeException
        System.out.println("Enter the position into which thw value has to be added : ");
        int pos = sc.nextInt(); // Critical statment --> InputMismatchException
        System.out.println("Enter the value which that has to be added: ");
        int val = sc.nextInt(); // Critical statment --> InputMismatchException
        arr[pos] = val; // Critical statment --> ArrayIndexOutOfBoundException
        System.out.println("value added to position");
        }
        //generic catch bloack
        catch(Exception e){
            System.out.println("Exception handled");
        }
    }
    
}
