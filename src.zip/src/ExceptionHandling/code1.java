package ExceptionHandling;

import java.util.Scanner;

// exception : These are the mistakes done by the end user in giving the proper input during the exception time.
//             Exception can also occur during compilation time as well.
//Critical statment : The lines that are bound to throw an exception.
public class code1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the 1st number: ");
        int num1 = sc.nextInt(); // Critical statment --> InputMismatchException
        System.out.println("enter the 2nd number: ");
        int num2 = sc.nextInt(); // Critical statment --> InputMismatchException
        int res = num1/num2; // Critical statment --> ArithmethicException
        System.out.println("result : "+res);

        System.out.println("======================");
        System.out.println("enter the array size: ");
        int n= sc.nextInt(); // Critical statment --> InputMismatchException
        int arr[] = new int[n]; // Critical statment --> NegativeArraySizeException
        System.out.println("Enter the position into which thw value has to be added : ");
        int pos = sc.nextInt(); // Critical statment --> InputMismatchException
        System.out.println("Enter the value which that has to be added: ");
        int val = sc.nextInt(); // Critical statment --> InputMismatchException
        arr[pos] = val; // Critical statment --> ArrayIndexOutOfBoundException
        System.out.println("value added to position");
    }
    
}
/*
 * The above code was handled by default handler exception handler e=which is also called as the universal 
 * exception handler which can handle any exception
 */