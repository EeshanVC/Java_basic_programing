package Projects;

import java.util.Scanner;

public class CrorepathiGame {
    static Scanner sc = new Scanner(System.in);
    static boolean audiencePollUsed = false, fiftyFiftyUsed = false, skipUsed = false;

    public static void main(String[] args) {
        String[][] questions = {
            {"Which company manufactures the 'Hayabusa' motorcycle?", "Kawasaki", "Yamaha", "Suzuki", "Honda", "C", "A"},
            {"What is the engine displacement of a Royal Enfield Classic 350?", "250cc", "350cc", "500cc", "650cc", "B", "A"},
            {"Which of these is an American motorcycle brand?", "Ducati", "Harley-Davidson", "KTM", "BMW", "B", "A"},
            {"Which motorcycle brand produces the 'Ninja' series?", "Yamaha", "Kawasaki", "Honda", "Ducati", "B", "A"},
            {"What does 'cc' stand for in engine specifications?", "Cubic Cylinder", "Cubic Centimeter", "Central Combustion", "Cycle Capacity", "B", "A"},
            {"Which bike is known as the 'Widowmaker' due to its speed?", "Yamaha R1", "Suzuki GSX-R1000", "Kawasaki Ninja H2", "Honda CBR1000RR", "C", "A"},
            {"Which motorcycle won the most MotoGP championships?", "Honda", "Yamaha", "Ducati", "Suzuki", "A", "C"},
            {"Which of these is an electric bike brand?", "Triumph", "Zero Motorcycles", "Benelli", "Aprilia", "B", "A"},
            {"What is the top speed of the Ducati Panigale V4?", "250 km/h", "300 km/h", "320 km/h", "350 km/h", "C", "A"},
            {"Which material is commonly used for lightweight motorcycle frames?", "Steel", "Aluminium", "Titanium", "Carbon Fiber", "B", "A"}
        };

        int[] rewards = {1000, 5000, 10000, 50000, 100000, 500000, 1000000, 5000000, 10000000, 70000000};
        int currentReward = 0;

        System.out.println("Welcome to Crorepathi Game!");

        for (int i = 0; i < questions.length; i++) {
            System.out.println("\nQuestion " + (i + 1) + " for Rs. " + rewards[i]);
            System.out.println(questions[i][0]);
            System.out.println("A. " + questions[i][1] + "\tB. " + questions[i][2]);
            System.out.println("C. " + questions[i][3] + "\tD. " + questions[i][4]);

            System.out.println("Do you want to use a lifeline? (yes/no)");
            String useLifeline = sc.next();

            if (useLifeline.equalsIgnoreCase("yes")) {
                useLifeline(i, questions);
            }

            System.out.println("Enter your answer (A/B/C/D): ");
            String answer = sc.next().toUpperCase();

            if (answer.equals(questions[i][5])) {
                currentReward = rewards[i];
                System.out.println("Correct! You have won Rs. " + currentReward);
            } else {
                System.out.println("Wrong answer! Game Over. You won Rs. " + currentReward);
                break;
            }
        }
        System.out.println("Thank you for playing!");
    }

    public static void useLifeline(int questionIndex, String[][] questions) {
        System.out.println("Choose a lifeline: ");
        if (!audiencePollUsed) System.out.println("1. Audience Poll");
        if (!fiftyFiftyUsed) System.out.println("2. 50-50");
        if (!skipUsed) System.out.println("3. Skip Question");

        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                if (!audiencePollUsed) {
                    audiencePollUsed = true;
                    System.out.println("Audience suggests the correct answer is: " + questions[questionIndex][5]);
                } else {
                    System.out.println("You already used this lifeline.");
                }
                break;
            case 2:
                if (!fiftyFiftyUsed) {
                    fiftyFiftyUsed = true;
                    System.out.println("Remaining options: " + questions[questionIndex][5] + " and " + questions[questionIndex][6]);
                } else {
                    System.out.println("You already used this lifeline.");
                }
                break;
            case 3:
                if (!skipUsed) {
                    skipUsed = true;
                    System.out.println("Skipping this question...");
                } else {
                    System.out.println("You already used this lifeline.");
                }
                break;
            default:
                System.out.println("Invalid choice or lifeline already used.");
        }
    }
}