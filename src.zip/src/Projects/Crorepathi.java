package Projects;

import java.util.Scanner;

public class Crorepathi {
    static Scanner scanner = new Scanner(System.in);
    static boolean audienceUsed = false, fiftyFiftyUsed = false, skipUsed = false;
    static int prizeMoney = 0;

    public static void main(String[] args) {
        String[][] questions = {
            {"What is the capital of India?", "Delhi", "Mumbai", "Kolkata", "Chennai", "1"},
            {"Who is known as the Father of the Nation in India?", "Nehru", "Gandhi", "Patel", "Bose", "2"},
            {"Which planet is known as the Red Planet?", "Earth", "Mars", "Jupiter", "Venus", "2"},
            {"Which is the largest ocean?", "Atlantic", "Indian", "Arctic", "Pacific", "4"},
            {"What is the national animal of India?", "Tiger", "Lion", "Elephant", "Deer", "1"},
            {"Who wrote 'Ramayana'?", "Valmiki", "Tulsidas", "Vyasa", "Kalidasa", "1"},
            {"What is the currency of Japan?", "Yen", "Dollar", "Rupee", "Won", "1"},
            {"Which gas do plants use for photosynthesis?", "Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen", "2"},
            {"Who was the first President of India?", "Nehru", "Gandhi", "Rajendra Prasad", "Ambedkar", "3"},
            {"What is the chemical symbol for Gold?", "Ag", "Au", "Pb", "Pt", "2"}
        };
        
        for (int i = 0; i < questions.length; i++) {
            if (!askQuestion(questions[i])) {
                System.out.println("Game Over! You won Rs. " + prizeMoney);
                return;
            }
        }
        System.out.println("Congratulations! You are a Crorepathi! Total Winning: Rs. " + prizeMoney);
    }
    
    static boolean askQuestion(String[] question) {
        System.out.println("\nQuestion: " + question[0]);
        System.out.println("1. " + question[1] + "  2. " + question[2]);
        System.out.println("3. " + question[3] + "  4. " + question[4]);
        System.out.println("Enter your answer (1-4), type 5 for Life Line, or type 0 to Quit: ");
        
        int answer = scanner.nextInt();
        if (answer == 0) {
            System.out.println("You have quit the game with Rs. " + prizeMoney);
            System.exit(0);
        }
        
        if (answer == 5) {
            useLifeLine(question);
            return askQuestion(question);
        }
        
        if (String.valueOf(answer).equals(question[5])) {
            prizeMoney += 1000000;
            System.out.println("Correct Answer! You won Rs. " + prizeMoney);
            return true;
        } else {
            System.out.println("Wrong Answer! The correct answer was: " + question[Integer.parseInt(question[5])]);
            return false;
        }
    }
    
    static void useLifeLine(String[] question) {
        System.out.println("Available Life Lines: ");
        if (!audienceUsed) System.out.println("1. Audience Poll");
        if (!fiftyFiftyUsed) System.out.println("2. 50-50");
        if (!skipUsed) System.out.println("3. Skip Question");
        
        System.out.println("Enter your choice (1-3): ");
        int choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
                if (!audienceUsed) {
                    audienceUsed = true;
                    System.out.println("Audience suggests option " + question[5]);
                } else {
                    System.out.println("Audience Poll already used!");
                }
                break;
            case 2:
                if (!fiftyFiftyUsed) {
                    fiftyFiftyUsed = true;
                    System.out.println("50-50 Lifeline: One correct and one incorrect option remain.");
                    System.out.println("Option " + question[5] + " and one other displayed.");
                } else {
                    System.out.println("50-50 already used!");
                }
                break;
            case 3:
                if (!skipUsed) {
                    skipUsed = true;
                    System.out.println("Skipping question...");
                    prizeMoney += 1000000;
                    return;
                } else {
                    System.out.println("Skip already used!");
                }
                break;
            default:
                System.out.println("Invalid Choice!");
        }
    }
}
