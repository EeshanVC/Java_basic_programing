package TCS_REFERENCE_PROGRAM;
import java.util.Arrays;
import java.util.Scanner;

public class Program6 {
	public static void main(String[] args) {
		//Step:1
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first string : ");
		String str1 = sc.next();
		System.out.println("Enter the second string : ");
		String str2 = sc.next();
		System.out.println("------------------");
		//step:2
		if(str1.length()==str2.length()) {
			//step:3
			char[] c1 = str1.toCharArray();
			char[] c2 = str2.toCharArray();
			//step:4
			Arrays.sort(c1);
			Arrays.sort(c2);
			//step:5
			if(Arrays.equals(c1, c2)==true) {
				System.out.println("The strings are anagrams");
			}
			else {
				System.out.println("The strings are not anagrams");
			}
		}
		else {
			System.out.println("The strings are not anagrams");
		}
	}
}
