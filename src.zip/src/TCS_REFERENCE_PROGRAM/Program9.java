package TCS_REFERENCE_PROGRAM;
//WAP to replace all vowels with $ in the given string
//WAP to find the sum of all vowels in the given string
import java.util.Scanner;

public class Program9 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
		String str_temp = "";
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)=='a' || str.charAt(i)=='e' ||str.charAt(i)=='i' ||str.charAt(i)=='o' 
					|| str.charAt(i)=='u' ||
					str.charAt(i)=='A' || str.charAt(i)=='E' ||str.charAt(i)=='I' 
					||str.charAt(i)=='O' || str.charAt(i)=='U') {
				str_temp = str_temp + '$';
			}else {
				str_temp = str_temp + str.charAt(i);
			}
		}
	System.out.println("replaced string = "+str_temp);
	}
}
