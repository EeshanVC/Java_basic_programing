package TCS_REFERENCE_PROGRAM;

//WAP to check if the given array contains all the alphabets of English (consider the alphabets are of lower case)
public class Program3 {
	public static void main(String[] args) {
		char arr[] = {'a','b','q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j'
				,'k','l','z','x','c','v','b','n','m','g','f','d','s','a','e','r','t','y','u','i'};
		int res[] = new int[26];
		for(int i=0;i<res.length;i++) {
			res[i] = 0;
		}
		//res[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		int temp = 0;
		for(int i=0;i<arr.length;i++) {
			//find the difference between the character in array & 'a'
			temp = arr[i] - 'a';//a-a=> 97-97=>0,b-a=>98-97=1
			res[temp] = 1;//res[0]=1,res[1]=1,
		}
		System.out.println("------------------");
		for(int i=0;i<res.length;i++) {
			if(res[i]!=1) {
				System.out.println("This array does not contain all the alphabets of English");
				System.exit(0);
			}
		}
		System.out.println("The array contains all the alphabets of English");
	}
}
