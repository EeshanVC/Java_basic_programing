package TCS_REFERENCE_PROGRAM;
//WAP to check if the given 2 strings are anagrams or not with using builtin methods
/*
 * Step:1 Collect the strings
 * Step:2 Create 2 arrays which is having the size same as 
 * 		  the 2 strings provided the string have same size else directly print that the 
 * 		  string are not anagrams
 * Step:3 Traverse the string and store the characters into the array
 * Step:4 Sort the arrays using bubble sort algorithm
 * Step:5 Compare the 2 arrays for equality
 */
import java.util.Scanner;
class Sorting{
	char[] sort(char c[]) {
		char temp;
		for(int i=0;i<c.length-1;i++) {
			for(int j=i+1;j<c.length;j++) {
				if(c[i]>c[j]) {
					temp=c[i];
					c[i]=c[j];
					c[j]=temp;
				}
			}
		}
		return c;
	}
}
public class Program5 {
	public static void main(String[] args) {
		//Step:1
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first string : ");
		String str1 = sc.next();
		System.out.println("Enter the second string : ");
		String str2 = sc.next();
		System.out.println("------------------");
		
		//Step:2
		if(str1.length()==str2.length()) {
			char c1[] = new char[str1.length()];
			char c2[] = new char[str2.length()];
			
			//step:3
			for(int i=0;i<str1.length();i++) {
				c1[i] = str1.charAt(i);
				c2[i] = str2.charAt(i);
			}
			
			//step:4
			//sorting array c1
			Sorting s = new Sorting();
			c1 = s.sort(c1);
			//sorting array c2
			c2 = s.sort(c2);
			
			for(Character c : c1) {
				System.out.print(c+" ");
			}
			System.out.println();
			System.out.println("---------------");
			for(Character c : c2) {
				System.out.print(c+" ");
			}
			System.out.println();
			System.out.println("---------------");
			
			//step:5
			for(int i=0;i<c1.length;i++) {
				if(c1[i]!=c2[i]) {
					System.out.println("The strings are not anagrams");
					System.exit(0);
				}
			}
			System.out.println("The strings are anagrams");
		}
		else {
			System.out.println("The strings are not anagrams");
		}
	}
}


