package TCS_REFERENCE_PROGRAM;
//WAP to find the sum of all vowels in the given string
//WAP to replace indivitual vowels with separate special characters
import java.util.Scanner;

public class Program10 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
		int sum = 0;
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)=='a' || str.charAt(i)=='e' ||str.charAt(i)=='i' ||str.charAt(i)=='o' 
					|| str.charAt(i)=='u' ||
					str.charAt(i)=='A' || str.charAt(i)=='E' ||str.charAt(i)=='I' 
					||str.charAt(i)=='O' || str.charAt(i)=='U') {
				sum = sum + str.charAt(i);
			}
		}
	System.out.println("sum of vowels in the string = "+sum);
	}
}
