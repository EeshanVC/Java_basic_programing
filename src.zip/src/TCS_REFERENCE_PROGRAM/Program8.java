package TCS_REFERENCE_PROGRAM;
//WAP to replace all vowels with $ and all consonants with & in the given string
//WAP to replace all vowels with $ in the given string
import java.util.Scanner;

public class Program8 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
		str=str.toLowerCase();
		String str_temp = "";
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)>=97 && str.charAt(i)<=122) {
				if(str.charAt(i)=='a' || str.charAt(i)=='e' ||str.charAt(i)=='i' ||str.charAt(i)=='o' 
						|| str.charAt(i)=='u' ) {
					str_temp = str_temp + '$';
				}else {
					str_temp = str_temp + '&';
				}
			}
			else {
				str_temp = str_temp + str.charAt(i);
			}
		}
		System.out.println("replaced string = "+str_temp);
	}
}
