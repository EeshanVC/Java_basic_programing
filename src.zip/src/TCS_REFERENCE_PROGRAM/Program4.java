package TCS_REFERENCE_PROGRAM;
//WAP to check if the given string is palindrome or not without using built in reverse function

import java.util.Scanner;

public class Program4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("ENter the string");
		String str = sc.next();//mom
		
		String str_temp = "";
		for(int i=str.length()-1;i>=0;i--) {
			str_temp = str_temp + str.charAt(i);
			//mom
		}
		if(str.equals(str_temp)==true) {
			System.out.println("the string is palindrome");
		}
		else {
			System.out.println("the string is not a palindrome");
		}
	}
}
