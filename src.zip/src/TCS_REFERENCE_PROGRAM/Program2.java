package TCS_REFERENCE_PROGRAM;
//WAP to find the minimum and maximum value from the given array using bubble sort algorithm
public class Program2 {
	public static void main(String[] args) {
		int arr[] = {100,50,150,25,75,125,115};
		System.out.println("Array before sorting : ");
		for(Integer i : arr) {
			System.out.print(i+" ");
		}
		System.out.println();
		System.out.println("--------------");
		int temp =0;
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];//temp=100, temp=50
					arr[i]=arr[j];//arr[i]=50, arr[i]=25
					arr[j]=temp;//arr[j]=100, arr[j]=50
				}
			}
		}
		for(Integer i : arr) {
			System.out.print(i+" ");
		}
		System.out.println();
		System.out.println("--------------");
		System.out.println("Element with minimum value is = "+arr[0]);
		System.out.println("Element with maximum value is = "+arr[arr.length-1]);
	}
}
