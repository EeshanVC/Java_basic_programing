package StringPrograming;

public class StringCode4 {
    public static void main(String[] args) {
        String str = "MahendarSinghDhoni";
        System.out.println(str);
        System.out.println("----------");

        String upperCase = str.toUpperCase();
        System.out.println(upperCase);
        System.out.println("----------");

        String lowerCase = str.toLowerCase();
        System.out.println(lowerCase);
        System.out.println("----------");
        
        boolean res = str.startsWith("Mahendar");
        System.out.println(res);
        System.out.println("----------");
        res = str.startsWith("Mahendra");
        System.out.println(res);
        System.out.println("----------");
        res = str.endsWith("Dhoni");
        System.out.println(res);
        System.out.println("----------");
        res = str.endsWith("Ghoni");
        System.out.println(res);
        System.out.println("----------");
        res = str.contains("Singh");
        System.out.println(res);
        System.out.println("----------");
        res = str.contains("Mingh");
        System.out.println(res);
        System.out.println("----------");
        char c = str.charAt(5); // return character
        System.out.println(c);
        System.out.println("----------");
        int i = str.charAt(5);  // return ascii
        System.out.println(i);
        System.out.println("----------");
        // i = str.charAt(50); //return ascii
        // System.out.println(i);
        // System.out.println("-----------");
    }


}
