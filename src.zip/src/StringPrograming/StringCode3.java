package StringPrograming;


/*
 * name of the method  : compareToIgnoreCase(String s)
 * no of parameters    : 1
 * type of parameret   : String 
 * return type         : Integer
 * Description         : 
 */
public class StringCode3 {
    public static void main(String[] args) {
        String s1="Rama";
        String s2="Rama";

        if(s1.compareToIgnoreCase(s2)==0){
            System.out.println("strings are equal");
        }else{
            System.out.println(s1.compareTo(s2));
            System.out.println("strings are not equal");
        }
        System.out.println("--------------------------");

        //reference check/address check
        if(s1==s2){
            System.out.println("references are equal");
        }else{
            System.out.println("reference are not equal");
        }
    }
    
}


