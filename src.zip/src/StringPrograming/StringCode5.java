package StringPrograming;

public class StringCode5 {

    public static void main(String[] args) {
        String str = "Mahendar Singh Dhoni";
        System.out.println(str);
        System.out.println("----------");
        int i = str.charAt('S'); //return ascii
        System.out.println(i);
        System.out.println("-----------");
        i = str.charAt('Z'); //return ascii
        System.out.println(i);
        System.out.println("-----------");
        Class c = str.getClass();
        System.out.println(c);
        System.out.println("----------");
        str.concat("is the finest wicket keeper");
        System.out.println(str);
        System.out.println("---------------");
        System.out.println("Immutable strings conot be directly changed we have force the change:");
        str = str.concat("is the finest wicket keeper");
        System.out.println(str);
        System.out.println("-----------------");
        int hashCode = str.hashCode();
        System.out.println(hashCode);
        System.out.println("-----------------");
        boolean res = str.isBlank();
        System.out.println(res);
        System.out.println("-----------------");
        String str2= "  ";
        res = str2.isBlank();
        System.out.println(res);
        System.out.println("-----------------");
        String str3= "";
        res = str3.isBlank();
        System.out.println(res);
        System.out.println("-----------------");
        res= str.isEmpty();
        System.out.println(res);
        System.out.println("-----------------");
        res= str2.isEmpty();
        System.out.println(res);
        System.out.println("-----------------");
        res= str3.isEmpty();
        System.out.println(res);
        System.out.println("-----------------");

    }
}    