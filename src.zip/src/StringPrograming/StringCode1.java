package StringPrograming;
public class StringCode1 {
    public static void main(String[] args) {
        String s1="Rama";
        String s2="Rama";

        if(s1.equals(s2)==true){
            System.out.println("strings are equal");
        }else{
            System.out.println("strings are not equal");
        }
        System.out.println("--------------");

        //reference check/address check
        if(s1==s2){
            System.out.println("references are equal");
        }else{
            System.out.println("reference are not equal");
        }
    }
    
}