package StringPrograming;

public class StringCode12 {
    public static void main(String[] args) {
        //immutable string
String s1 = "Sita";
String s2 = "Ravana";
s1.concat(s2);
System.out.println(s1);//Sita
System.out.println("---------------");
StringBuffer sb1 = new StringBuffer("Sita");
StringBuffer sb2 = new StringBuffer("Rama");
sb1.append(sb2);
System.out.println(sb1);
System.out.println("----------------");
StringBuilder sbu1 = new StringBuilder("Sita");
StringBuilder sbu2 = new StringBuilder("Rama");
sbu1.append(sbu2);
System.out.println(sbu1);
    }
    
}
