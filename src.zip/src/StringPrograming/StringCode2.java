package StringPrograming;


/*
 * name of the method  : compareTo(String s)
 * no of parameters    : 1
 * type of parameret   : String 
 * return type         : Integer
 * Description         : check if the string is equal or not. if not equal it will return 
 *                       the difference b/w first mis-matched characters
 */
public class StringCode2 {
    public static void main(String[] args) {
        String s1="Rama";
        String s2="Rama";

        if(s1.compareTo(s2)==0){
            System.out.println("strings are equal");
        }else{
            System.out.println(s1.compareTo(s2));
            System.out.println("strings are not equal");
        }
        System.out.println("--------------------------");

        //reference check/address check
        if(s1==s2){
            System.out.println("references are equal");
        }else{
            System.out.println("reference are not equal");
        }
    }
    
}


