
package com.patternprograms;

import java.util.Scanner;
/*
12 34 5
1 2 3 4 5
12 3 4 5
1 2 3 4 5
1 2 3 4 5
*/
public class Program6 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the count :");
			int n = sc.nextInt();
// using nested loops
			for (int i = 1; i <= n; i++)// rows
			{
				for (int j = 1; j <= n; j++)// columns
				{
					System.out.print(i+" ");
				}
				System.out.println();
			}
		}
	}
