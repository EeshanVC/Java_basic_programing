package com.patternprograms;

import java.util.Scanner;

public class ALPHABETAB {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size: ");
        System.out.println("EESHAN V C 4PM21AI014");

        int n = sc.nextInt();
        sc.close();

        for (int i = 0; i < n; i++) {
            // Printing "A"
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || i == 0 || i == n / 2) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "B"
            for (int j = 0; j < n; j++) {
                if (j == 0 || (j == n - 1 && i != 0 && i != n - 1 && i != n / 2) || i == 0 || i == n / 2 || i == n - 1) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "C"
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || j == 0) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "D"
            for (int j = 0; j < n; j++) {
                if (j == 0 || (j == n - 1 && i != 0 && i != n - 1) || i == 0 || i == n - 1) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "E"
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || i == n / 2 || j == 0) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "F"
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n / 2 || j == 0) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "G"
            for(int j=0;j<n;j++) {
				if(i==0 && j!=0 || j==0 && i!=0 && i!=(n-1) || i==(n-1) && j!=0 && j<=(n/2) ||
				   j==(n/2) && i>(n/2) || i==(n/2) && j>(n/2) && j!=(n-1) || j==(n-1) && i>(n/2)) {
					System.out.print("^ ");
				}else {
					System.out.print("  ");
				}
			}
            System.out.print("  ");

            // Printing "H"
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || i == n / 2) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "I"
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || j == n / 2) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Printing "J"
            for (int j = 0; j < n; j++) {
                if (i == 0 || (j == n / 2 && i != n - 1) || (i == n - 1 && j < n / 2)) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

  
            for (int j = 0; j < n; j++) {
                if (j == 0 || i + j == n / 2 || i - j == n / 2) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

  
            for (int j = 0; j < n; j++) {
                if (j == 0 || i == n - 1) {
                    System.out.print("^ ");
                } else {
                    System.out.print("  ");
                }
            }
            
            System.out.println("  "); 
            
         // Letter M
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || (i == j && j <= n / 2) || (i + j == n - 1 && j >= n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println(); // Move to next row

        }
    }
}