package com.patternprograms;

import java.util.Scanner;

public class AlphabetAZ {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size :");
        System.out.println("EESHAN V C4PM21AI014");

        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            // Letter A
            for (int j = 0; j < n; j++) {
                if ((i == 0 && j != 0 && j != (n - 1)) || i == (n / 2) || (j == 0 && i != 0) || (j == (n - 1) && i != 0)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter B
            for (int j = 0; j < n; j++) {
                if (j == 0 || (i == 0 && j != (n - 1)) || (i == (n / 2) && j != (n - 1))
                        || (i == (n - 1) && j != (n - 1)) || (j == (n - 1) && i != 0 && i != (n / 2) && i != (n - 1))) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter C
            for (int j = 0; j < n; j++) {
                if (i == 0 && j != 0 || i == (n - 1) && j != 0 || j == 0 && i != (n - 1)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter D
            for (int j = 0; j < n; j++) {
                if (j == 0 || (i == 0 && j != (n - 1)) || (i == (n - 1) && j != (n - 1)) || j == (n - 1) && i != 0 && i != (n - 1)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter E
            for (int j = 0; j < n; j++) {
                if (j == 0 || i == 0 || i == n / 2 || i == n - 1) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter F
            for (int j = 0; j < n; j++) {
                if (j == 0 || i == 0 || i == n / 2) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter G
            for(int j=0;j<n;j++) {
				if(i==0 && j!=0 || j==0 && i!=0 && i!=(n-1) || i==(n-1) && j!=0 && j<=(n/2) ||
				   j==(n/2) && i>(n/2) || i==(n/2) && j>(n/2) && j!=(n-1) || j==(n-1) && i>(n/2)) {
					System.out.print("# ");
				}else {
					System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter H
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || i == n / 2) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter I
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || j == n / 2) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter J
            for (int j = 0; j < n; j++) {
                if (i == 0 || (j == n / 2 && i < n - 1) || (i == n - 1 && j < n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter K
            for (int j = 0; j < n; j++) {
                if (j == 0 || i + j == n / 2 || i - j == n / 2) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter L
            for (int j = 0; j < n; j++) {
                if (j == 0 || i == n - 1) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 
            
            // Letter M
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || (i == j && j <= n / 2) || (i + j == n - 1 && j >= n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter N
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || i == j) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  "); 

            // Letter O
            for (int j = 0; j < n; j++) {
                if ((i == 0 && j != 0 && j != n - 1) || (i == n - 1 && j != 0 && j != n - 1) || (j == 0 && i != 0 && i != n - 1) || (j == n - 1 && i != 0 && i != n - 1)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }

            System.out.print("  "); 

            // Letter P
            for (int j = 0; j < n; j++) {
                if (j == 0 || (i == 0 && j != n - 1) || (i == n / 2 && j != n - 1) || (j == n - 1 && i < n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter Q
            for (int j = 0; j < n; j++) {
                if ((i == 0 && j != 0 && j != n - 1) || (i == n - 1 && j != 0 && j != n - 1) 
                        || (j == 0 && i != 0 && i != n - 1) || (j == n - 1 && i != 0 && i != n - 1)
                        || (i == j && i >= n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter R
            for (int j = 0; j < n; j++) {
                if (j == 0 || (i == 0 && j != n - 1) || (i == n / 2 && j != n - 1) || (j == n - 1 && i < n / 2) 
                        || (i - j == n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter S
            for (int j = 0; j < n; j++) {
                if ((i == 0 && j != 0) || (i == n / 2 && j != 0 && j != n - 1) || (i == n - 1 && j != n - 1) 
                        || (j == 0 && i < n / 2) || (j == n - 1 && i > n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter T
            for (int j = 0; j < n; j++) {
                if (i == 0 || j == n / 2) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter U
            for (int j = 0; j < n; j++) {
                if ((j == 0 || j == n - 1) && i != n - 1 || (i == n - 1 && j != 0 && j != n - 1)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter V
            for (int j = 0; j < n; j++) {
                if ((j == 0 || j == n - 1) && i < n - 2 || (i == n - 2 && j == n / 2) || (i == n - 1 && j != 0 && j != n - 1)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter W
            for (int j = 0; j < n; j++) {
                if (j == 0 || j == n - 1 || (i == n - 2 && (j == n / 4 || j == (3 * n) / 4)) || (i == n - 1 && j == n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter X
            for (int j = 0; j < n; j++) {
                if (i == j || i + j == n - 1) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter Y
            for (int j = 0; j < n; j++) {
                if ((i == j && i < n / 2) || (i + j == n - 1 && i < n / 2) || (j == n / 2 && i >= n / 2)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");

            // Letter Z
            for (int j = 0; j < n; j++) {
                if (i == 0 || i == n - 1 || i + j == n - 1) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }

            System.out.println(); // Move to next row
        }
    }
}
