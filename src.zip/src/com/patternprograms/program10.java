package com.patternprograms;

import java.util.Scanner;

public class program10 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the count :");
			int n = sc.nextInt();
			// using nested loops
			for (int i = 1; i <= n; i++)// rows
			{
				for (int j = 1; j <= i; j++)// columns
				{
					System.out.print("$ ");
				}
				System.out.println();

			}

		}

	}
