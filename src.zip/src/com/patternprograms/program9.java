package com.patternprograms;
import java.util.*;

/*
 1  6  11 16 21 
 2  7  12 17 22
 3  8  13 18 23
 4  9  14 19 24
 5  10 15 20 25
 */
public class program9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the count :");
		int n = sc.nextInt();
		int count;
		// using nested loops
		for (int i = 1; i <= n; i++)// rows
		{
			count =i;
			for (int j = 1; j <= n; j++)// columns
			{
				System.out.print(count+"    ");
				count = count+5;
			}
			System.out.println();

		}

	}

}
