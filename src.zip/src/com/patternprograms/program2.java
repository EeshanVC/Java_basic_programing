package com.patternprograms;
import java.util.*;


/*
 #
 #
 #
 #
 #
 */

public class program2 {

	public static void main(String[] args) {
		

	}

}
