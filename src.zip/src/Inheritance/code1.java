package Inheritance;
class parent{
    private int accno;
    private int password;

    void setaccno(){
        accno = 111;
        password = 222;
    }

}
class child extends parent{
    void modify(){
        accno = 123; //error
        password = 321;  //error
    }
}
public class code1 {
    
}
