package Inheritance;

class plane{
    void takeoff(){
        System.out.println("plane took off");
    }
    void fly(){
        System.out.println("plane is flying");
    }
    void land(){
        System.out.println("plane is landing");
    }
}

class cargoPlane extends plane{
    //annotations are extra information given to the program to make it error free
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("cargo plane is flying");
    }
    void carryGoods(){
        System.out.println("cargo plane carry goods");
    }
}
class passengerPlane extends plane{
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("passenger plane is flying at medium height ");
    }
    void carryHumans(){
        System.out.println("passenger plane carry humans");
    } 
}
class fighterPlane extends plane{
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("fighter plane is flying at great height");
    }
    void carryWeapons(){
        System.out.println("fighter plane carry weapons");
    }
} 

//Polymorphsim: It refers to the feature where we can exhibit 1:M relationship
//Parent type reference to child type objects
public class code5 {
    public static void main(String[] args) {
        plane ref;//plane reference
        cargoPlane cp = new cargoPlane();
        ref=cp;
        ref.takeoff();
        ref.fly();
        ref.land();
        cp.carryGoods();//parent reference cannot point to specialized methods of Child
        System.out.println("----------------");
        passengerPlane pp = new passengerPlane();
        ref=pp;
        ref.takeoff();
        ref.fly();
        ref.land();
        pp.carryHumans();
        System.out.println("----------------");
        fighterPlane fp = new fighterPlane();
        ref=fp;
        ref.takeoff();
        ref.fly();
        ref.land();
        fp.carryWeapons();
    }
}