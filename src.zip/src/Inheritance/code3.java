package Inheritance;
class plane{
    void takeoff(){
        System.out.println("plane took off");
    }
    void fly(){
        System.out.println("plane is flying");
    }
    void land(){
        System.out.println("plane is landing");
    }
}

class cargoPlane extends plane{
    //annotations are extra information given to the program to make it error free
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("cargo plane is flying");
    }
    void carryGoods(){
        System.out.println("cargo plane carry goods");
    }
}
class passengerPlane extends plane{
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("passenger plane is flying at medium height ");
    }
    void carrypassenger(){
        System.out.println("passenger plane carry humans");
    } 
}
class fighterPlane extends plane{
    @Override //indicate that the given method is overriden
    void fly(){
        System.out.println("fighter plane is flying at great height");
    }
    void carryWeapons(){
        System.out.println("fighter plane carry weapons");
    }
} 
public class code3 {
    public static void main(String[] args) {
        cargoPlane c= new cargoPlane();
        c.takeoff();
        c.fly();
        c.land();
        c.carryGoods();
        System.out.println("========================");
        passengerPlane p =new passengerPlane();
        p.takeoff();
        p.fly();
        p.land();
        p.carrypassenger();
        System.out.println("========================");
        fighterPlane f = new fighterPlane();
        f.takeoff();
        f.fly();
        f.land();
        f.carryWeapons();
    }
}
