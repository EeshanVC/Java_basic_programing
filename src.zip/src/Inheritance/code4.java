package Inheritance;

class animal{
    void eat(){
        System.out.println("Animal eats.");
    }
    void sleep(){
        System.out.println("Animal sleeps.");
    }
    void walk(){
        System.out.println("Animal walks.");
    }
}
class elephant extends animal{
    @Override
    void eat(){
        System.out.println("Elephant eats.");
    }
    void trumpet(){
        System.out.println("Elephant trumpets.");
    }
}
class tiger extends animal{
    @Override
    void eat(){
        System.out.println("Tiger eats");
    }
    void roars(){
        System.out.println("Tiger roars.");
    }
}
class dog extends animal{
    @Override
    void eat(){
        System.out.println("Dog eats.");
    }
    void bark(){
        System.out.println("DOg barks.");
    }
}
public class code4 {
    public static void main(String[] args) {
        animal a = new animal();
        a.eat();
        a.sleep();
        a.walk();
        elephant e = new elephant();
        e.eat();
        e.trumpet();
        tiger t = new tiger();
        t.eat();
        t.roars();
        dog d = new dog();
        d.eat();
        d.bark();
    }
}
