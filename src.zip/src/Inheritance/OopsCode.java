package Inheritance;

import java.util.*;

abstract class Shapes{
    double area;
    abstract void collect();
    abstract void calculate();
    void display() {
    System.out.println(area);
    }
}
class Circle extends Shapes{
    private double radius;
    private final static double pi=3.1476;
    @Override
    void collect() {
    Scanner sc =new Scanner(System.in);
    System.out.println("Enter the radius: ");
    radius = sc.nextDouble();
    }
    @Override
    void calculate() {
    area = pi * radius * radius;
    }
}
class Square extends Shapes{
    private double side;
    @Override
    void collect() {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter the side: ");
        side = sc.nextDouble();
        }
        @Override
        void calculate() {
        area = side*side;
        }
}
class Rectangle extends Shapes{
    private double l,b;
    @Override
    void collect() {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter the lenght: ");
        l = sc.nextDouble();
        System.out.println("Enter the breadth: ");
        b = sc.nextDouble();
        }
        @Override
        void calculate() {
        area = l * b;
        }
}

class Geometry{
    void permit(Shapes s){
        s.collect();
        s.calculate();
        s.display();
    }

}
public class OopsCode {
    public static void main(String[] args) {
        Circle c= new Circle();
        Square s= new Square();
        Rectangle r= new Rectangle();

        Geometry g=new Geometry();

        g.permit(c);
        System.out.println("------------------------");
        g.permit(s);
        System.out.println("------------------------");
        g.permit(r);
        System.out.println("------------------------");
    }
}

