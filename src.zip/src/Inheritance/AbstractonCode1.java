package Inheritance;
// abstraction refers to process of hiding implementation from parent class 
//and forcing the child to provide implementation 
// A class is termed as abstract class if and only if it contain atleast method. 
//but from java 1.8 we can make a class as abstract without the abstract method in it.
//abstract method is a method which does not have any implementation but has only the signture 
// which is associated eith abstract keyword
//we cannot creste the object of an abstract a sit caontains unimplementation methods 

abstract class plane1{
    void takeoff(){
        System.out.println("plane took off");
    }
    abstract void fly();
    void land(){
        System.out.println("plane is landing");
    }
}

class cargoPlane1 extends plane1{
    @Override
    public void fly(){
        System.out.println("cargo plane is flying");
    }
}
class passengerPlane1 extends plane1{
    @Override
    public void fly(){
        System.out.println("passenger plane is flying");
    } 
}
class fighterPlane1 extends plane1{
    @Override
    public void fly(){
        System.out.println("Fighter plane is flying ");
    }
}
public class AbstractonCode1 {
    public static void main(String[] args) {
        cargoPlane1 cp1 = new cargoPlane1();
        cp1.takeoff();
        cp1.fly();
        cp1.land();
        System.out.println("====================");
        passengerPlane1 pp1 = new passengerPlane1();
        pp1.takeoff();
        pp1.fly();
        pp1.land();
        System.out.println("====================");
        fighterPlane1 fp1 = new fighterPlane1();  
        fp1.takeoff();
        fp1.fly();
        fp1.land();
        System.out.println("====================");

//      plane1 p1 = new plane1() //error
        //creating object using anonymous inner types
        plane1 p2 = new plane1() {
            @Override
            void fly(){
                System.out.println("hi from fly");
            }
        };
        System.out.println(p2);
    }    
}
