package Inheritance;

class animal{
    public animal(){
        super();
        System.out.println("this is from animal constructor");
    }

    public animal(String string){
        super();
        System.out.println("this is from animal constructor");
        System.out.println(string);
    }
}
class elphant extends animal{
    public elphant(){
        super();
        System.out.println("this is from elephant constructor");
    }
}
class tiger extends animal{
    public tiger(){
        super("this is the message from tiger");
        System.out.println("this is from tiger constructor");
    }
}
public class code2 {
    public static void main(String[] args) {
        elphant e = new elphant();
        System.out.println("==========================");
        tiger t = new tiger();
    }
}
