package Overloading;

class Calculator {
    int add(int a, int b){
        return a+b;
    }
    float add(float a, float b){
        return a+b;
    }
    float add(int a, float b){
        return a+b;
    }
    float add(float a, int b){
        return a+b;
    }
    float add(int a, int b, int c){
        return a+b+c;
    }
    float add(int a, float b, float c){
        return a+b+c;
    }
    double add(double a, double b){
        return a+b;
    }
    double add(double a, double b, double c){
        return a+b+c;
    }
    double add(int a, double b){
        return a+b;
    }
    double add(double a, int b){
        return a+b;
    }
    double add(float a, double b){
        return a+b;
    }
    double add(Double a, Float b){
        return a+b;
    }
}

public class OverloadCode1{
    public static void main(String[] args) {
        Calculator c1 = new Calculator();
        int a=10, b=20, c =30;
        float m=13.56f,n=23.56f,o=33.56f;
        double p=1234.4321, q=2345.5432, r=3456.6543;
        System.out.println(c1.add(a,b));
        System.out.println(c1.add(p,b));
        System.out.println(c1.add(a,q));
        System.out.println(c1.add(r,q));
        System.out.println(c1.add(m,n));
        System.out.println(c1.add(a,m));
        System.out.println(c1.add(n,b));
        System.out.println(c1.add(a,b,c));
        System.out.println(c1.add(p,q,r));
    }
}
