package staticSegment;
import java.util.*;

class aadhar {
    String name;
    int age;
    long aadharNo;
    static String country;
    
    static {
        country = "India";
    }
    
    void collect() {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter your name: ");
        name = sc.nextLine();
        System.out.println("enter u r age: ");
        age = sc.nextInt();
        
        if (age < 15) {
            System.out.println("Sorry, you are not eligible for an Aadhaar card.");
            return;
        }
        
        System.out.println("enter Aadhar Number: ");
        aadharNo = sc.nextLong();
    }
    
    void display() {
        if (age < 15) {
            return;
        }
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Aadhar Number: " + aadharNo);
        System.out.println("country: " + country);
    }
}

public class program3 {
    public static void main(String[] args) {
        aadhar applicant1 = new aadhar();
        applicant1.collect();
        applicant1.display();
        
        System.out.println("-------------------");
        
        aadhar applicant2 = new aadhar();
        applicant2.collect();
        applicant2.display();
    }
}




