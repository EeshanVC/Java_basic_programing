// applicatione of static keyword

package staticSegment;
import java.util.*;

class farmer{
    double principle;
    static double rate;
    double time;
    double simple_int;

    static{
        rate= 5.678;
    }

    void collect(){
        Scanner sc = new Scanner(System.in);
        System.out.println("rnter principle: ");
        principle = sc.nextDouble();
        System.out.println("enter time");
        time = sc.nextDouble();

    }
    void cal(){
        simple_int = (principle *rate *time)/100;
    }
    void dis(){
        System.out.println("simple interest = "+ simple_int);
    }
}
public class program2 {
    public static void main(String[] args) {
        farmer f1 = new farmer();
        f1.collect();
        f1.cal();
        f1.dis();
        System.out.println("--------------");
        farmer f2 = new farmer();
        f2.collect();
        f2.cal();
        f2.dis();
        System.out.println("-----------------");
        farmer f3 = new farmer();
        f3.collect();
        f3.cal();
        f3.dis();
        System.out.println("-----------------");
        farmer f4 = new farmer();
        f4.collect();
        f4.cal();
        f4.dis();
    }
}
