package staticSegment;


class sample{
    static int a, b, c;//static variables
    int p,q,r; // non static variables

    static{
    //static block : This will not have any name or access modifiers but it will have only static.It can access only static variables
    a=100;//accessible
    b=200;//accessible
    c=300;//accessible
    // p=111;//not accessible as it is non-static variable
    // q=222;//not accessible as it is non-static variable
    // r=333;//not accessible as it is non-static variable
    }
    //non-static block: This will not have any name or access modifiers nothing.
    //It can access static variables and non-static variables
    {
    a=1010;//accessible
    b=2020;//accessible
    c=3030;//accessible
    p=101;//accessible
    q=202;//accessible
    r=303;//accessible
    }
    //static method: method which can access only static variables and associated with static keyword
    static void display1() {
    System.out.println(a);//accessible
    System.out.println(b);//accessible
    System.out.println(c);//accessible
    // System.out.println(p);//not accessible as it is non-static variable
    // System.out.println(q);//not accessible as it is non-static variable
    // System.out.println(r);//not accessible as it is non-static variable
    }
    //non-static method: method which can access both static & non slatic variables
    void display2() {
    System.out.println(a);//accessible
    System.out.println(b);//accessible
    System.out.println(c);//accessible
    System.out.println(p);//accessible
    System.out.println(q);//accessible
    System.out.println(r);//accessible 
    }    
}
public class program1 {
    public static void main(String[] args) {
        sample.display1();
        sample.a=999;
        sample.b=888;
        sample.c=777;
        System.out.println("==========");
        sample.display1();
        System.out.println("============");
        sample s =new sample();
        s.display1();
        System.out.println("===========");
        s.display2();
    }
    
}
