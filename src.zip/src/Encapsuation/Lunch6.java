package Encapsuation;

class cricket{
    private String name;
    private String country;
    private int matches;
    private int catches;
    private int runs;
    private int wickets;

    //specific setters
    void setName(String name) {
    this.name=name;
    }
    void setCountry(String country) {
    this.country=country;
    }
    void setMatches(int matches) {
    this.matches=matches;
    }
    void setCatches(int catches) {
    this.catches=catches;
    }
    void setRuns(int runs) {
    this.runs=runs;
    }
    void setWickets(int wickets) {
    this.wickets=wickets;
    }

    //specific getter

    String getName(){
        return name;
    }
    String getCountry(){
        return country;
    }
    int getMatches(){
        return matches;
    }
    int getCatches(){
        return catches;
    }
    int getRuns(){
        return runs;
    }
    int getWickets(){
        return wickets;
    }
    
}
public class Lunch6 {
        public static void main(String[] args) {
            cricket c= new cricket();
            c.setName("sachin");
            c.setCountry("India");
            c.setMatches(180);
            c.setCatches(200);
            c.setRuns(4000);
            c.setWickets(60);

            System.out.println(c.getName());
            System.out.println(c.getCountry());
            System.out.println(c.getMatches());
            System.out.println(c.getCatches());
            System.out.println(c.getRuns());
            System.out.println(c.getWickets());


        }
}
