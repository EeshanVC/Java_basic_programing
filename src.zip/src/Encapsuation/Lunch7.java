package Encapsuation;

import java.util.*;

class Employee {
    private String name;
    private String department;
    private int id;
    private double salary;
    private int experience;
    private String designation;

    // Specific setters
    void setName(String name) {
        this.name = name;
    }
    void setDepartment(String department) {
        this.department = department;
    }
    void setId(int id) {
        this.id = id;
    }
    void setSalary(double salary) {
        this.salary = salary;
    }
    void setExperience(int experience) {
        this.experience = experience;
    }
    void setDesignation(String designation) {
        this.designation = designation;
    }

    // Specific getters
    String getName() {
        return name;
    }
    String getDepartment() {
        return department;
    }
    int getId() {
        return id;
    }
    double getSalary() {
        return salary;
    }
    int getExperience() {
        return experience;
    }
    String getDesignation() {
        return designation;
    }
}

public class Lunch7 {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setName("ee");
        e.setDepartment("AI");
        e.setId(101);
        e.setSalary(50000);
        e.setExperience(5);
        e.setDesignation("Associate Engineer");

        System.out.println(e.getName());
        System.out.println(e.getDepartment());
        System.out.println(e.getId());
        System.out.println(e.getSalary());
        System.out.println(e.getExperience());
        System.out.println(e.getDesignation());
    }
}
