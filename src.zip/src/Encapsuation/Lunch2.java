package Encapsuation;

class Dog2{
    private String name;
    private String color;
    private String breed;
    private int cost;
    private int age;

    void set(String a, String b, String c, int d, int e){
        name = a;
        color = b;
        breed = c;
        cost = d;
        age = e;
    }
    
    void get(){
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed);
        System.out.println(cost);
        System.out.println(age);

    }
}
public class Lunch2 {
public static void main(String[] args) {
    Dog2 d2 = new Dog2();
    d2.set("tommy", "blue", "g", 400, 5);
    d2.get();
}
}


