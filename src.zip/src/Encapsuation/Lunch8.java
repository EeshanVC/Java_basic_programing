package Encapsuation;
// class without a parent is called as orphan class and it will be adopted bt object class.
class Dog8{ // orphan class // extends Object : since there is no parent for dog object class will be its parent
    private String name;
    private String color;
    private String breed;
    private int cost;
    private int age;

    //constructor representation
    Dog8(){
        this("rocky"); // local chaining -- looking for 1 parameterized constructor
        this.name = "jammy";
        this.color = "color";
        this.breed = "breed";
        this.cost = 4000;
        this.age = 5;
        System.out.println("printing the data for 0 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }

    Dog8(String name){
        this("jipsey","black"); // local chaining -- looking for 2 parameterized constructor
        this.name= name;
        System.out.println("printing the data for 1 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }
    Dog8(String name, String color){
        this("rock","white","puug"); // local chaining -- looking for 3 parameterized constructor
        this.name= name;
        this.color = color;
        System.out.println("printing the data for 2 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }

    public Dog8(String name, String color, String breed){
        this("jack","red","p", 9000); // local chaining -- looking for 4 parameterized constructor
        this.name= name;
        this.color = color;
        this.breed = breed ;
        System.out.println("printing the data for 3 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }

    public Dog8(String name, String color, String breed, int cost){
        this("jacky","yellow","g", 5000,1); // local chaining -- looking for 5 parameterized constructor
        this.name= name;
        this.color = color;
        this.breed = breed ;
        this.cost = cost;
        System.out.println("printing the data for 4 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }
    public Dog8(String name, String color, String breed, int cost, int age){
        super(); // takes control to parent class constructor here it is object class
        this.name= name;
        this.color = color;
        this.breed = breed ;
        this.cost = cost;
        this.age = age;
        System.out.println("printing the data for 5 parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }

    void display(){
        System.out.println("--------------------------------------");
        System.out.println("printing the data final parameterized constructor");
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed );
        System.out.println(cost);
        System.out.println(age);
        System.out.println("=============================");
    }

}
public class Lunch8 {
    public static void main(String[] args) {
        Dog8 d8 = new Dog8();
        d8.display();

    }
}
