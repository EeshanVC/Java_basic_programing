package Encapsuation;

import java.util.*;
class Dog5{
    private String name;
    private String color;
    private String breed;
    private int cost;
    private int age;

    void set(String nmae, String color, String breed, int cost, int age){
        this.name = name;
        this.color = color;
        this.breed = breed;
        this.cost = cost;
        this.age = age;
    }


    void get(){
        System.out.println(name);
        System.out.println(color);
        System.out.println(breed);
        System.out.println(cost);
        System.out.println(age);

    }
}
// public class Lunch3 {
// public static void main(String[] args) {
//     Dog1 d1 = new Dog1();
//     d1.set();
//     d1.get();
// }
// }

public class Lunch5 {
    public static void main(String[] args) {
        Dog5 d = new Dog5();
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the name: ");
        String name= sc.next();
        System.out.println("enter the color: ");
        String color= sc.next();
        System.out.println("enter the breed: ");
        String breed= sc.next();
        System.out.println("enter the cost: ");
        int cost= sc.nextInt();
        System.out.println("enter the age: ");
        int age= sc.nextInt();
        d.set(name, color, breed, cost, age);
        d.get();
    }
    }

