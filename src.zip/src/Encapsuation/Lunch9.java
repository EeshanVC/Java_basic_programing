package Encapsuation;
class Tiger{
    // given by complier if not mentioned by user / programer
    Tiger(){
        super();
    }
}
public class Lunch9 {
    public static void main(String[] args) {
        Tiger t = new Tiger();  // calls zero parameterized constructor
        Tiger t1 = new Tiger("name"); //error as one parameterized constructor is not present 
    }
}
