// package Encapsuation;

// class Dog1{
//     private String name;
//     private String color;
//     private String breed;
//     private int cost;
//     private int age;


// }
//     public class Lunch1 {
//         public static void main(String[] args) {
//             Dog1 d1 = new Dog1(); // cannot access private members directly from another class 
//             d1.name = "dog";  // cannot access private members directly from another class 
//             d1.color = "blue";  // cannot access private members directly from another class 
//             d1.breed = "G";  // cannot access private members directly from another class 
//             d1.cost = 4000; // cannot access private members directly from another class 
//             d1.age = 4; // cannot access private members directly from another class 
//         }
//     }


