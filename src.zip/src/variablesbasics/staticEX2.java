package variablesbasics;

import java.util.Scanner;

class sample {
    static int a,b,c;
    int p,q,r;

    static{

        a=100;//acces is permitted as it is a static variable 
        b=200;//acces is permitted as it is a static variable 
        c=300;//acces is permitted as it is a static variable 
        //p=1000;//acces is not permitted as it is a static variable 
        //q=2000;//acces is not permitted as it is a static variable 
       // r=3000;//acces is not permitted as it is a static variable 
    }
    {
        a=101;//acces is permitted 
        b=201;//acces is permitted 
        c=301;//acces is permitted  
        p=1001;//acces is permitted  
        q=2001;//acces is permitted 
        r=3001;//acces is permitted  
    }
    static void display1(){

        System.out.println(a);//acces is permitted as it is a static variable 
        System.out.println(b);//acces is permitted as it is a static variable 
        System.out.println(c);//acces is permitted as it is a static variable 
    //  System.out.println(p);//acces is not permitted as it is a static variable 
    //  System.out.println(q);//acces is not permitted as it is a static variable 
    //  System.out.println(r);//acces is not permitted as it is a static variable 
    }
    void display2(){
        // access only stat
        System.out.println(a);//Access is permitted  
        System.out.println(b);//Access is permitted  
        System.out.println(c);//Access is permitted 
        System.out.println(p);//acces is  permitted 
        System.out.println(q);//acces is permitted  
        System.out.println(r);//acces is permitted
    }
}

public class staticEX2 {
    public static void main(String[] args) {
        // a moment main method is executed the static block will be executed 
        sample.a=222;
        sample.b=333;
        sample.c=444;
        sample.display1();
        sample s = new sample();

        s.display2();
        s.display1();
    }
}
