package variablesbasics;
import java.util.*;
class Farmer {
	double principle;
	double time;
	static double rate; //inside static segment and memory is created only once
	double smple_intr;
	
	//static block
	static {
		rate = 8.76;
	}
	
	void collectData() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter principle");
		principle =sc.nextDouble();
		System.out.println("Enter time");
		time = sc.nextDouble();
	}
	
	void calculate() {
		smple_intr = (principle * time * rate)/100;
	}
	
	void display() {
		System.out.println("the simple interest = "+smple_intr);
	}
}

public class staticEX1 {

	public static void main(String[] args) {
		Farmer f1 = new Farmer();
		Farmer f2 = new Farmer();
		Farmer f3 = new Farmer();
		
		f1.collectData();
		f1.calculate();
		f1.display();
		System.out.println("-----------");
		f2.collectData();
		f2.calculate();
		f2.display();
		System.out.println("-----------");
		f3.collectData();
		f3.calculate();
		f3.display();
		System.out.println("-----------");
	}

}
