package variablesbasics;
class Dogs {
	String name;
	String color;
	String breed;
	int cost;
	int age;
	
	void display() {
		System.out.println(name);
		System.out.println(color);
		System.out.println(breed);
		System.out.println(cost);
		System.out.println(age);

	}
	}
	public class Dog {
		public static void main(String[] args) {
			Dog d = new Dog();
		}
	}
