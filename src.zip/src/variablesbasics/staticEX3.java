package variablesbasics;

import java.util.Scanner;

class Candidate{
    int aadhar_no;
    String name;
    String email;
    String addr_line;
    String city;
    String state;
    static String country;
    String pincode;

    static{
        country ="India";
    }
    void collectData(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter aadhar number");
        aadhar_no = sc.nextInt();
        System.out.println("Enter name");
        name=sc.next();
        System.out.println("Enter email");
        email =sc.next();
        System.out.println("Enter address ");
        addr_line = sc.next();
        System.out.println("Enter city");
        city = sc.next();
        System.out.println("Enter pincode");
        pincode=sc.next();
    }

    void display(){
        System.out.println(aadhar_no);
        System.out.println(name);
        System.out.println(email);
        System.out.println(addr_line);
        System.out.println(city);
        System.out.println(country);
        System.out.println(pincode);
    }

}
public class staticEX3 {
    public static void main(String[] args) {
        Candidate c1 =new Candidate();
        c1.collectData();
        c1.display();

        Candidate c2 = new Candidate();
        c2.collectData();
        c2.display(); 
    }
}
