package InterfaceExample;

// 1. Interface in java is defined as the collection of public abstract method, static method, default methos and public static final variables.
// 2. With the help of interface we cam achieve 100% abstraction
// 3. We can use the properties of an interface using implements keyword
// 4. With the help of interface we can also achieve polymorphism
// 5. With the help of interface we can also achieve standardization of code
// 6. We cannot create the object of an interface directly, but we can create a reference directly
// 7. We can create the object of an interface using Anonymous inner types
// 8. Though we cannot create the object of an interface directly
// we can certainly create the reference of an interface directly
// 9. As we know multiple inheritance cannot be achieved using
// extends keyword but using the implements keyword we can achieve multiple inheritance.
// 10. One interface cannot implement another interface because both contains abstract methods
// 11. Any method inside an interface without default and static reference is by default made as abstract
// 12. Though one interface cannot implement another interface
// it can certainly extend another interface (is-a relationship is permitted)
// 13. Any variable declared inside an interface is by default
// made as public static final which means the values is created in static segment and cannot be altered
// 14. In java an empty interface is called as tagged interface/marker interface
// 15. If a class extends another class and implements an interface as well then we must extend first and then implement
// 16. From java 1.8 an interface can also be the home for default and static implemented methods
// 17. From java 1.8 we can make an interface contain only one abstract method i.e by using functional interface concept.
// 18. A functional interface indicated by @FunctionalInterface
// is applied to ensure that the interface cannot have more than 1 abstract method.

interface calculator1{
    void add();
}
interface calculator2{
    void add();
}
//point 10
interface calculator3 implements calculator2{

}
//point 12,13
interface calculator4 extends calculator2{

}
class calcy{
}
//point 15
class calcy1 extends calcy implements calculator2{
    @Override
    public void add();{
    }
}
//point 17,18
@FunctionalInterface
interface calculator5{
    void add();
}
//point 9
class calcy1 implements calculator1,calculator2{
    @Override
    public void sub(){
    }
    @Override
    public void add(){}
}

public class Example2 {
    
}
